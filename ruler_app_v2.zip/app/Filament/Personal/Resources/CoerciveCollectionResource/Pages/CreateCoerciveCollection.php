<?php

namespace App\Filament\Personal\Resources\CoerciveCollectionResource\Pages;

use App\Filament\Personal\Resources\CoerciveCollectionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCoerciveCollection extends CreateRecord
{
    protected static string $resource = CoerciveCollectionResource::class;
}
