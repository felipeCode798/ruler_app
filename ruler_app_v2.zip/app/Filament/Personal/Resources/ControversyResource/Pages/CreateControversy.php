<?php

namespace App\Filament\Personal\Resources\ControversyResource\Pages;

use App\Filament\Personal\Resources\ControversyResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateControversy extends CreateRecord
{
    protected static string $resource = ControversyResource::class;
}
