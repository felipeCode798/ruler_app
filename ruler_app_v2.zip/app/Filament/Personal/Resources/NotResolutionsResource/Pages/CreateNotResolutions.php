<?php

namespace App\Filament\Personal\Resources\NotResolutionsResource\Pages;

use App\Filament\Personal\Resources\NotResolutionsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNotResolutions extends CreateRecord
{
    protected static string $resource = NotResolutionsResource::class;
}
