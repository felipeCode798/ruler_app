<?php

namespace App\Filament\Personal\Resources\PaymentAgreementResource\Pages;

use App\Filament\Personal\Resources\PaymentAgreementResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePaymentAgreement extends CreateRecord
{
    protected static string $resource = PaymentAgreementResource::class;
}
