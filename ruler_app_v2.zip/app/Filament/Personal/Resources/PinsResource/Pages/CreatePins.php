<?php

namespace App\Filament\Personal\Resources\PinsResource\Pages;

use App\Filament\Personal\Resources\PinsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePins extends CreateRecord
{
    protected static string $resource = PinsResource::class;
}
