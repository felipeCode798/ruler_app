<?php

namespace App\Filament\Personal\Resources\PrescriptionResource\Pages;

use App\Filament\Personal\Resources\PrescriptionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePrescription extends CreateRecord
{
    protected static string $resource = PrescriptionResource::class;
}
