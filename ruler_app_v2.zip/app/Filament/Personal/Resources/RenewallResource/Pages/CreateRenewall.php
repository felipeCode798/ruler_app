<?php

namespace App\Filament\Personal\Resources\RenewallResource\Pages;

use App\Filament\Personal\Resources\RenewallResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRenewall extends CreateRecord
{
    protected static string $resource = RenewallResource::class;
}
