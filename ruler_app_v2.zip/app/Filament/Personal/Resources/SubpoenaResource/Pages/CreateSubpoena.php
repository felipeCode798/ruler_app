<?php

namespace App\Filament\Personal\Resources\SubpoenaResource\Pages;

use App\Filament\Personal\Resources\SubpoenaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSubpoena extends CreateRecord
{
    protected static string $resource = SubpoenaResource::class;
}
