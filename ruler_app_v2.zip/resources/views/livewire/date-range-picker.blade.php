<div>
    <label for="start_date">Start Date</label>
    <input type="date" wire:model="startDate" id="start_date">

    <label for="end_date">End Date</label>
    <input type="date" wire:model="endDate" id="end_date">
</div>
